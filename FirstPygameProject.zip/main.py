"""
 Pygame base template for opening a window

 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/

 Explanation video: http://youtu.be/vRB_983kUMc
"""

import pygame
import random
import pygame.freetype

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
LBLUE = (0, 255, 255)

pygame.init()

# Set the width and height of the screen [width, height]
size = (1000, 700)
screen = pygame.display.set_mode(size)

pygame.display.set_caption("My Game")

# Loop until the user clicks the close button.
done = False
game_over = False

# Used to manage how fast the screen updates
clock = pygame.time.Clock()

maps = ["OOOOOOOOOOOOOOOOOOOOOOOOO",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "O_______________________O",
        "OOOOOOOOOOOOOOOOOOOOOOOOO"]

maps_inside = ["_________________________",
               "_O________________________",
               "_OOO___________e_________",
               "___OOOOOOOO______________",
               "___p__O_____________s____",
               "______O__________________",
               "______O_______e__________",
               "______O__________________",
               "____OOOOOOOOO____________",
               "____O_______O____________",
               "____O_______O______e_____",
               "_______e____O____________",
               "____________O____________",
               "_________________________",
               "_________________________"]

maps_inside2 = ["_________________________",
                "_O________________________",
                "_OOO___O___________e_____",
                "___OOOOO_OO______________",
                "______O_________O________",
                "________________O____s___",
                "______O_________O________",
                "______O_________O________",
                "____OOOO_OOOOOOOO____e___",
                "____O_______O____________",
                "____O____________________",
                "____O_______O______e______",
                "_______e____O____________",
                "___________________e_____",
                "_________________________"]


class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, score, keys, money, health):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((40, 40))
        self.image = pygame.image.load("player.png")
        self.image.set_colorkey(WHITE)
        self.rect = self.image.get_rect()

        self.rect.y = y
        self.rect.x = x

        self.health = health
        self.money = money
        self.score = score
        self.keys = keys

    def update(self, movementx, movementy):
        self.rect.x += movementx
        self.rect.y += movementy


class Wall(pygame.sprite.Sprite):
    def __init__(self, wallx, wally):
        super().__init__()
        self.image = pygame.Surface((40, 40))
        self.image = pygame.image.load("wall.png")
        self.rect = self.image.get_rect()
        self.rect.x = wallx
        self.rect.y = wally


class WallInside(pygame.sprite.Sprite):
    def __init__(self, wall_insidex, wall_insidey):
        super().__init__()
        self.image = pygame.Surface((40, 40))
        self.image = pygame.image.load("wall.png")
        self.rect = self.image.get_rect()
        self.rect.x = wall_insidex
        self.rect.y = wall_insidey


class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((40, 40))
        self.image = pygame.image.load("enemy.png")
        self.rect = self.image.get_rect()

        self.rect.y = y
        self.rect.x = x

        self.health = 500

    def update(self, movementx, movementy):
        self.rect.x += movementx
        self.rect.y += movementy


class Portal(pygame.sprite.Sprite):
    def __init__(self, wallx, wally):
        super().__init__()
        self.image = pygame.Surface((40, 40))
        self.image = pygame.image.load("portal.png")
        self.rect = self.image.get_rect()
        self.rect.x = wallx
        self.rect.y = wally


class SpeedPu(pygame.sprite.Sprite):
    def __init__(self, wallx, wally):
        super().__init__()
        self.image = pygame.Surface((40, 40))
        self.image = pygame.image.load("pu.png")
        self.rect = self.image.get_rect()
        self.rect.x = wallx
        self.rect.y = wally


all_sprites_list = pygame.sprite.Group()
wall_list = pygame.sprite.Group()
enemy_list = pygame.sprite.Group()
portal_list = pygame.sprite.Group()
speedpu_list = pygame.sprite.Group()
lvl = 1

while not game_over:

    # spawning the player
    if lvl == 1:
        player = Player(600, 300, 0, 0, 0, 1500)
        all_sprites_list.add(player)

    # resetting if level 2
    if lvl == 2:
        save_score = player.score
        save_health = player.health
        save_keys = player.keys
        save_money = player.money
        save_x = player.rect.x
        save_y = player.rect.y

        all_sprites_list = pygame.sprite.Group()
        wall_list = pygame.sprite.Group()
        enemy_list = pygame.sprite.Group()
        portal_list = pygame.sprite.Group()
        speedpu_list = pygame.sprite.Group()

    if lvl == 2:
        player = Player(save_x, save_y, save_score, save_keys, save_money, save_health + 500)
        all_sprites_list.add(player)
        done = False

    # spawning the outside walls

    for i in range(25):
        for j in range(15):
            if maps[j][i] == "O":
                wall = Wall(i * 40, j * 40)
                all_sprites_list.add(wall)
                wall_list.add(wall)

    # spawning the inside walls
    if lvl == 1:
        for i in range(25):
            for j in range(15):
                if maps_inside[j][i] == "O":
                    wall_inside = WallInside(i * 40, j * 40)
                    all_sprites_list.add(wall_inside)
                    wall_list.add(wall_inside)
    if lvl == 2:
        for i in range(25):
            for j in range(15):
                if maps_inside2[j][i] == "O":
                    wall_inside = WallInside(i * 40, j * 40)
                    all_sprites_list.add(wall_inside)
                    wall_list.add(wall_inside)

    # spawning the enemies
    if lvl == 1:
        for i in range(25):
            for j in range(15):
                if maps_inside[j][i] == "e":
                    enemy = Enemy(i * 40, j * 40)
                    all_sprites_list.add(enemy)
                    enemy_list.add(enemy)

    if lvl == 2:
        for i in range(25):
            for j in range(15):
                if maps_inside2[j][i] == "e":
                    enemy = Enemy(i * 40, j * 40)
                    all_sprites_list.add(enemy)
                    enemy_list.add(enemy)
    # Spawning portal
    if lvl == 1:
        for i in range(25):
            for j in range(15):
                if maps_inside[j][i] == "p":
                    portal = Portal(i * 40, j * 40)
                    all_sprites_list.add(portal)
                    portal_list.add(portal)

    if lvl == 2:
        for i in range(25):
            for j in range(15):
                if maps_inside2[j][i] == "p":
                    portal = Portal(i * 40, j * 40)
                    all_sprites_list.add(portal)
                    portal_list.add(portal)

    # spawning speed powerups
    if lvl == 1:
        for i in range(25):
            for j in range(15):
                if maps_inside[j][i] == "s":
                    speedpu = SpeedPu(i * 40, j * 40)
                    all_sprites_list.add(speedpu)
                    speedpu_list.add(speedpu)

    if lvl == 2:
        for i in range(25):
            for j in range(15):
                if maps_inside2[j][i] == "s":
                    speedpu = SpeedPu(i * 40, j * 40)
                    all_sprites_list.add(speedpu)
                    speedpu_list.add(speedpu)

    speed_x = 0
    speed_y = 0

    if lvl > 1:
        speed_x = save_speed_x
        speed_y = save_speed_y

    # -------- Main Program Loop -----------

    current_health = 0
    current_score = 0
    current_money = 0
    max_speed = 10
    speedincrease = False
    speed_timer = 0

    while not done:
        # --- Main event loop
        wall_stop = pygame.sprite.spritecollide(player, wall_list, False)

        if wall_stop:
            stopped_x = player.rect.x - speed_x
            stopped_y = player.rect.y - speed_y

        speedpu_stop = pygame.sprite.spritecollide(player, speedpu_list, False)

        if speedpu_stop:
            speed_x *= 2
            speed_y *= 2
            speedincrease = True
            speedpu_stop[0].kill()

        if speedincrease:
            max_speed = 20
            speed_timer += 1

        if speed_timer == 300:
            speed_x /= 2
            speed_y /= 2
            max_speed = 10
            speed_timer = 0
            speedincrease = False


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
                game_over = True
            # Player movement
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_d:
                    speed_x += max_speed
                if event.key == pygame.K_a:
                    speed_x -= max_speed
                if event.key == pygame.K_w:
                    speed_y -= max_speed
                if event.key == pygame.K_s:
                    speed_y += max_speed
            # Removing the movement when letting go
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_d:
                    speed_x -= max_speed
                if event.key == pygame.K_a:
                    speed_x += max_speed
                if event.key == pygame.K_w:
                    speed_y += max_speed
                if event.key == pygame.K_s:
                    speed_y -= max_speed

        if wall_stop:
            player.rect.x = stopped_x
            player.rect.y = stopped_y
        # for i in range(wall_list.length):
        # if (player.rect.x + speed_y)//40 = (wall(i).rect.x//40):

        enemy_stop = pygame.sprite.spritecollide(player, enemy_list, False)

        if enemy_stop:
            hit = random.randint(1, 3)
            if hit == 3:
                player.health -= 50
            else:
                enemy_stop[0].health -= 50

        if player.health == 0:
            done = True
            game_over = True
        if enemy_stop:
            if enemy_stop[0].health == 0:
                enemy_stop[0].kill()
                enemy_stop[0].health = -1
                player.score += 1
                if not enemy_list:
                    player.keys += 1

        current_health = player.health
        current_score = player.score
        current_money = player.money
        current_keys = player.keys

        level = pygame.sprite.spritecollide(player, portal_list, False)

        if level and player.keys == 1:
            lvl += 1
            done = True
            save_speed_x = speed_x
            save_speed_y = speed_y

        # Constantly updating the player position
        player.update(speed_x, speed_y)

        # --- Game logic should go here

        # --- Screen-clearing code goes here

        # Here, we clear the screen to white. Don't put other drawing commands
        # above this, or they will be erased with this command.

        # If you want a background image, replace this clear with blit'ing the
        # background image.
        screen.fill(WHITE)
        all_sprites_list.update(0, 0)

        all_sprites_list.draw(screen)
        # --- Drawing code should go here

        health_text = pygame.freetype.SysFont("Arial", 30)
        health_display, _ = health_text.render("Health = " + str(current_health), BLACK)
        screen.blit(health_display, (50, 600))

        score_text = pygame.freetype.SysFont("Arial", 30)
        score_display, _ = score_text.render("Score = " + str(current_score), BLACK)
        screen.blit(score_display, (510, 600))

        money_text = pygame.freetype.SysFont("Arial", 30)
        money_display, _ = money_text.render("Money = " + str(current_money), BLACK)
        screen.blit(money_display, (50, 650))

        keys_text = pygame.freetype.SysFont("Arial", 30)
        money_display, _ = money_text.render("Keys = " + str(current_keys), BLACK)
        screen.blit(money_display, (510, 650))

        # --- Go ahead and update the screen with what we've drawn.
        pygame.display.flip()

        # --- Limit to 60 frames per second
        clock.tick(60)

# Close the window and quit.
pygame.quit()
